//
//  ChestViewController.h
//  Workout
//
//  Created by mac on 4/1/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChestViewController : UIViewController<UIGestureRecognizerDelegate>
{
    IBOutlet UITableView *chestBodyTableView;
    IBOutlet UITableView *customExerciseTableView;
    IBOutlet UIView *addExercisePopUop;
    IBOutlet UIView *addExerCiseView;
    IBOutlet UITextField *exerciseTextfield;

}

@end
