//
//  SavedWorkOutViewController.h
//  Workout
//
//  Created by mac on 3/30/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SavedWorkOutViewController : UIViewController
{
    IBOutlet UITableView *savedTableview;
    
    
}
- (IBAction)byDateAction:(id)sender;




@end
