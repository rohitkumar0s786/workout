//
//  FinishViewController.m
//  Workout
//
//  Created by mac on 4/1/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "FinishViewController.h"
#import "WorkOutViewController.h"
#import "CustomViewController.h"

@interface FinishViewController ()

@end

@implementation FinishViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)countinueaAction:(id)sender {
    finishPopView.hidden = YES;
    CustomViewController *navToWorkbydate;
    
    navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"CustomViewController"];
    BOOL isPresent = NO;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:navToWorkbydate.class]) {
            [self.navigationController popToViewController:vc animated:YES];
            isPresent = YES;
        }
    }
    
    
    if (!isPresent) {
        //push controller
        [self.navigationController pushViewController:navToWorkbydate animated:YES];
        
    }

}


- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [self.view endEditing:YES];
    
    [self.view bringSubviewToFront:finishPopView];
    finishPopView.hidden = NO;
    return YES;
}


- (IBAction)backPopUp:(id)sender {
    
    finishPopView.hidden = YES;
    
}

- (IBAction)SaveDataYesButton:(id)sender {
    
    finishPopView.hidden = YES;

    
}
- (IBAction)backAction:(id)sender {
   
    WorkOutViewController *navToWorkbydate;
    
    navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"WorkOutViewController"];
    BOOL isPresent = NO;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:navToWorkbydate.class]) {
            [self.navigationController popToViewController:vc animated:YES];
            isPresent = YES;
        }
    }
    
    
    if (!isPresent) {
        //push controller
        [self.navigationController pushViewController:navToWorkbydate animated:YES];
        
    }
    

}
@end
