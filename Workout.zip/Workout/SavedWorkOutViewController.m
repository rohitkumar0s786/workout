
//
//  SavedWorkOutViewController.m
//  Workout
//
//  Created by mac on 3/30/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "SavedWorkOutViewController.h"
#import "SavedWorkOutCell.h"
#import "FSCalendarScopeExampleViewController.h"
#import "WorkOutViewController.h"

@interface SavedWorkOutViewController ()
{
    NSArray *Worklist;
//    SavedWorkOutCell *cell;
    NSDictionary *WorkOutFinalList;
    NSArray *WorkOutSectionTitles;
    NSArray *workIndexTitles;

}
@end

@implementation SavedWorkOutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    WorkOutFinalList =@{@"A" : @[@""],
                @"B" : @[@"Bear", @"Black Swan", @"Buffalo"],
                @"C" : @[@"Camel", @"Cockatoo"],
                @"D" : @[@"Dog", @"Donkey"],
                @"E" : @[@"Emu"],
                @"F" : @[@""],
                @"G" : @[@"Giraffe", @"Greater Rhea"],
                @"H" : @[@"Hippopotamus", @"Horse"],
                @"I" : @[@""],
                @"J" : @[@""],
                @"K" : @[@"Koala"],
                @"L" : @[@"Lion", @"Llama"],
                @"M" : @[@"Manatus", @"Meerkat"],
                @"N" : @[@""],
                @"O" : @[@""],
                @"P" : @[@"Panda", @"Peacock", @"Pig", @"Platypus", @"Polar Bear"],
                @"Q" : @[@""],
                @"R" : @[@"Rhinoceros"],
                @"S" : @[@"Seagull"],
                @"T" : @[@"Tasmania Devil"],
                @"U" : @[@""],
                @"V" : @[@""],
                @"W" : @[@"Whale", @"Whale Shark", @"Wombat"],
                @"X" : @[@""],
                @"Y" : @[@""],
                @"Z" : @[@""]
                        
                        };
    
    WorkOutSectionTitles = [[WorkOutFinalList allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    workIndexTitles = @[@"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K", @"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S", @"T", @"U", @"V", @"W", @"X", @"Y", @"Z"];
    // Do any additional setup after loading the view.
    
//    savedTableview.sectionIndexBackgroundColor = [UIColor redColor];
    for(UIView *view in [savedTableview subviews])
    {
        if([[[view class] description] isEqualToString:@"UITableViewIndex"])
        {
            
            [view setBackgroundColor:[UIColor whiteColor]];
            //            [view setFont:[UIFont systemFontOfSize:14]];
        }
    }

    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [WorkOutSectionTitles count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [workIndexTitles objectAtIndex:section];
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGRect viewFrame = self.view.frame;
    viewFrame.size.height = tableView.rowHeight/2;
    UIView *view = [[UIView alloc]  initWithFrame:viewFrame];
    UIImage *myImage = [UIImage imageNamed:[workIndexTitles objectAtIndex:section]];
    UIImageView *bgImag = [[UIImageView alloc] initWithFrame:viewFrame];
    bgImag.image = [UIImage imageNamed:@"bg"];
    [view addSubview:bgImag];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:myImage] ;
//    imageView.backgroundColor = [UIColor yellowColor];
    CGRect imageFrame = imageView.frame;
    imageFrame.origin.x = 15;
    imageView.frame = imageFrame;
    [view addSubview:imageView];
    return view;
    
}
//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 40;
//}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return tableView.rowHeight/2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *sectionTitle = [WorkOutSectionTitles objectAtIndex:section];
    NSArray *sectionAnimals = [WorkOutFinalList objectForKey:sectionTitle];
    return [sectionAnimals count];
    
//    return [Worklist count];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return WorkOutSectionTitles;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    SavedWorkOutCell *cell = (SavedWorkOutCell *)[tableView dequeueReusableCellWithIdentifier:@"SavedWorkOutCell" forIndexPath:indexPath];
    
    
    
    
    // Configure the cell...
    NSString *sectionTitle = [WorkOutSectionTitles objectAtIndex:indexPath.section];
    NSArray *sectionAnimals = [WorkOutFinalList objectForKey:sectionTitle];
    NSString *animal = [sectionAnimals objectAtIndex:indexPath.row];
    cell.savedLabel.text = animal;
    cell.savedBgImage.image = [UIImage imageNamed:[NSString stringWithFormat:@"holder_%@",[sectionTitle lowercaseString]]];
    
//    cell.imageView.image = [UIImage imageNamed:[self getImageFilename:animal]];
    
    return cell;
//
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
//    
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
//    }
//    
//    cell.textLabel.text = [Worklist objectAtIndex:indexPath.row];
//    return cell;
}
- (IBAction)backToPreView:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    WorkOutViewController *navToWorkbydate;
    
    navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"WorkOutViewController"];
    [self.navigationController pushViewController:navToWorkbydate animated:YES];

    
}


- (IBAction)byDateAction:(id)sender {
    FSCalendarScopeExampleViewController *navToWorkbydate;
    
    navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"FSCalendarScopeExampleViewController"];
    BOOL isPresent = NO;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:navToWorkbydate.class]) {
            [self.navigationController popToViewController:vc animated:YES];
            isPresent = YES;
        }
    }

    
    if (!isPresent) {
        //push controller
        [self.navigationController pushViewController:navToWorkbydate animated:YES];

    }
    

    
}
@end
