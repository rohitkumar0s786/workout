//
//  TempoScreenViewController.m
//  Workout
//
//  Created by mac on 4/2/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "TempoScreenViewController.h"
#import "WorkOutViewController.h"


@interface TempoScreenViewController ()

@end

@implementation TempoScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)saveWorkOutAction:(id)sender {
    WorkOutViewController *navToWorkbydate;
    
    navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"WorkOutViewController"];
    BOOL isPresent = NO;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:navToWorkbydate.class]) {
            [self.navigationController popToViewController:vc animated:YES];
            isPresent = YES;
        }
    }
    
    
    if (!isPresent) {
        //push controller
        [self.navigationController pushViewController:navToWorkbydate animated:YES];
        
    }


}
- (IBAction)backButton:(id)sender {

    [self.navigationController popViewControllerAnimated:YES];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
