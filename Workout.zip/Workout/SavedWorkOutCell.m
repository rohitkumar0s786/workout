//
//  SavedWorkOutCell.m
//  Workout
//
//  Created by mac on 3/30/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "SavedWorkOutCell.h"

@implementation SavedWorkOutCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
