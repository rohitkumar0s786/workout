//
//  ChestTableViewCell.h
//  Workout
//
//  Created by mac on 4/1/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChestTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *chestListImg;
@property (strong, nonatomic) IBOutlet UIImageView *cellImage;
@property (strong, nonatomic) IBOutlet UILabel *cellLabel;
@property (strong, nonatomic) IBOutlet UIButton *deleteButon;
@property (strong, nonatomic) IBOutlet UIImageView *swipeImage;
@property (strong, nonatomic) IBOutlet UILabel *swipeLabel;

@end
