//
//  CustomViewController.h
//  Workout
//
//  Created by mac on 3/31/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomViewController : UIViewController
{
    IBOutlet UITableView *customBodyTableView;
    IBOutlet UITableView *customExerciseTableView;
    IBOutlet UITextField *serachTextField;
    
}
- (IBAction)saveCustomWorkOutAction:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *saveCustomWorkOut;
- (IBAction)backAction:(id)sender;
- (IBAction)startCustomAction:(id)sender;
@end
