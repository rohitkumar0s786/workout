//
//  CustomTableViewCell.m
//  Workout
//
//  Created by mac on 3/31/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "CustomTableViewCell.h"

@implementation CustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.cusrtomImg.layer.borderWidth = 1.0f;
     self.cusrtomImg.layer.borderColor = [[UIColor colorWithRed:55/255.0f green:163/255.0f blue:220/255.0f alpha:1.0] CGColor];
    self.cusrtomImg.layer.cornerRadius = 8.0f;
    self.cusrtomImg.clipsToBounds= YES;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
   
    self.cusrtomImg.layer.borderWidth = 1.0f;
    self.cusrtomImg.layer.borderColor = [[UIColor colorWithRed:55/255.0f green:163/255.0f blue:220/255.0f alpha:1.0] CGColor];
    self.cusrtomImg.layer.cornerRadius = 8.0f;
    self.cusrtomImg.clipsToBounds= YES;
    
    // Configure the view for the selected state
}

@end
