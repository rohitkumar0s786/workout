//
//  WorkbydateViewController.m
//  Workout
//
//  Created by mac on 4/1/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "WorkbydateViewController.h"
#import "SavedWorkOutViewController.h"

@interface WorkbydateViewController ()

@end

@implementation WorkbydateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)savedWorkOutAction:(id)sender {
    
    SavedWorkOutViewController *navToSaveWork;
    
    navToSaveWork=[self.storyboard instantiateViewControllerWithIdentifier:@"SavedWorkOutViewController"];
    
    
    BOOL isPresent = NO;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:navToSaveWork.class]) {
            [self.navigationController popToViewController:vc animated:YES];
            isPresent = YES;
        }
    }
    
    
    if (!isPresent) {
        //push controller
        [self.navigationController pushViewController:navToSaveWork animated:YES];
        
    }
    
}
@end
