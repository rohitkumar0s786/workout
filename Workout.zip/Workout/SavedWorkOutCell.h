//
//  SavedWorkOutCell.h
//  Workout
//
//  Created by mac on 3/30/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SavedWorkOutCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *savedBgImage;
@property (strong, nonatomic) IBOutlet UILabel *savedLabel;

@end
