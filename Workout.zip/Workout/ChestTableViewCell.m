
//
//  ChestTableViewCell.m
//  Workout
//
//  Created by mac on 4/1/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "ChestTableViewCell.h"

@implementation ChestTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.cellImage.layer.borderWidth = 1.0f;
    self.cellImage.layer.borderColor = [[UIColor colorWithRed:55/255.0f green:163/255.0f blue:220/255.0f alpha:1.0] CGColor];
    self.cellImage.layer.cornerRadius = 8.0f;
    self.cellImage.clipsToBounds= YES;
    
    self.swipeImage.layer.borderWidth = 1.0f;
    self.swipeImage.layer.borderColor = [[UIColor colorWithRed:55/255.0f green:163/255.0f blue:220/255.0f alpha:1.0] CGColor];
    self.swipeImage.layer.cornerRadius = 8.0f;
    self.swipeImage.clipsToBounds= YES;
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
