

//
//  CustomViewController.m
//  Workout
//
//  Created by mac on 3/31/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "CustomViewController.h"
#import "CustomTableViewCell.h"
#import "ChestViewController.h"
#import "TempoScreenViewController.h"
#import "FinishViewController.h"

@interface CustomViewController ()
{
    CustomTableViewCell *CustomCell;
    NSMutableArray *CustomList,*exerciseList;
    
}
@end

@implementation CustomViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    serachTextField.placeholder
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    serachTextField.leftView = paddingView;
    serachTextField.leftViewMode = UITextFieldViewModeAlways;

    
    
    
    CustomList=[[NSMutableArray alloc] initWithObjects:@"chest",@"back",@"shoulders",@"legs",@"arms",@"cardio",@"all", nil];
    
    exerciseList=[[NSMutableArray alloc] initWithObjects:@"lat radses",@"front squat",@"bent over rows", nil];
    

    
    // Do any additional setup after loading the view.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (tableView == customBodyTableView) {
         return [CustomList count];
    }
    else{
        return [exerciseList count];

    
    }
    
      //count number of row from counting array hear cataGorry is An Array
}



- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    if (tableView == customBodyTableView) {
        static NSString *MyIdentifier = @"CustomCell";
        
        CustomCell=[tableView dequeueReusableCellWithIdentifier:MyIdentifier];
        CustomCell.cusrtomImg.tag=indexPath.row;
//        CustomCell.cusrtomImg.image=[UIImage imageNamed:[CustomList objectAtIndex:indexPath.row]];
        CustomCell.customlabel.text = [[NSString stringWithFormat:@"%@",[CustomList objectAtIndex:indexPath.row]] uppercaseString];
        

        
        
        //    INTROCELL.lbl.text=[catagorry objectAtIndex:indexPath.row];
        return CustomCell;
    }
    else{
        static NSString *MyIdentifier = @"CustomCell";
        
        CustomCell=[tableView dequeueReusableCellWithIdentifier:MyIdentifier];
        CustomCell.cusrtomImg.tag=indexPath.row;
//        CustomCell.cusrtomImg.image=[UIImage imageNamed:[exerciseList objectAtIndex:indexPath.row]];
       
        CustomCell.customlabel.text = [[NSString stringWithFormat:@"(%@) (5)",[exerciseList objectAtIndex:indexPath.row]] uppercaseString];
        
        //    INTROCELL.lbl.text=[catagorry objectAtIndex:indexPath.row];
        return CustomCell;
        
        
    }
    
    
    
    // Here we use the provided setImageWithURL: method to load the web image
    // Ensure you use a placeholder image otherwise cells will be initialized with no image
    //    [cell.imageView setImageWithURL:[NSURL URLWithString:@"http://example.com/image.jpg"]
    //                   placeholderImage:[UIImage imageNamed:@"placeholder"]];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)backAction:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)startCustomAction:(id)sender {
    TempoScreenViewController *navToWorkbydate;
    
    navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"TempoScreenViewController"];
    BOOL isPresent = NO;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:navToWorkbydate.class]) {
            [self.navigationController popToViewController:vc animated:YES];
            isPresent = YES;
        }
    }
    
    
    if (!isPresent) {
        //push controller
        [self.navigationController pushViewController:navToWorkbydate animated:YES];
        
    }
    

//    ChestViewController *navToWorkbydate;
//    
//    navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"ChestViewController"];
//    BOOL isPresent = NO;
//    for (UIViewController *vc in self.navigationController.viewControllers) {
//        if ([vc isKindOfClass:navToWorkbydate.class]) {
//            [self.navigationController popToViewController:vc animated:YES];
//            isPresent = YES;
//        }
//    }
//    
//    
//    if (!isPresent) {
//        //push controller
//        [self.navigationController pushViewController:navToWorkbydate animated:YES];
//        
//    }


}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [self.view endEditing: YES];
    return true;
}





- (IBAction)saveCustomWorkOutAction:(id)sender {
    FinishViewController *navToWorkbydate;
    
        navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"FinishViewController"];
        BOOL isPresent = NO;
        for (UIViewController *vc in self.navigationController.viewControllers) {
            if ([vc isKindOfClass:navToWorkbydate.class]) {
                [self.navigationController popToViewController:vc animated:YES];
                isPresent = YES;
            }
        }
    
    
        if (!isPresent) {
            //push controller
            [self.navigationController pushViewController:navToWorkbydate animated:YES];
            
        }
    

    
}
@end
