//
//  TempoScreenViewController.h
//  Workout
//
//  Created by mac on 4/2/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TempoScreenViewController : UIViewController

@end
