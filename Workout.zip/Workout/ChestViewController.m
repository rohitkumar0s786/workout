//
//  ChestViewController.m
//  Workout
//
//  Created by mac on 4/1/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import "ChestViewController.h"
#import "ChestTableViewCell.h"
#import "TempoScreenViewController.h"



@interface ChestViewController ()
{
    ChestTableViewCell *ChestCell;
    NSMutableArray *chestList,*chestexerciseList,*deleteEnable
    ;

}
@end

@implementation ChestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    addExerCiseView.layer.cornerRadius = 8.0f;
    addExerCiseView.clipsToBounds = YES;
    exerciseTextfield.layer.borderColor = [[UIColor whiteColor] CGColor];
    exerciseTextfield.layer.borderWidth = 1.0f;
    
    exerciseTextfield.layer.cornerRadius = 8.0f;
    exerciseTextfield.clipsToBounds = YES;
    
    
    chestList=[[NSMutableArray alloc] initWithObjects:@"btn_benchpress_active",@"btn_flies_active",@"btn_dips_active",@"btn_incline benchpress_active",@"btn_dumbbel bench press_active",@"btn_cable flies_active",@"btn_dumbbell flies_active",@"btn_inclines press_active",@"btn_inclines press_active", nil];
   NSMutableArray *exerciseList=[[NSMutableArray alloc] initWithObjects:@"lat radses",@"front squat",@"bent over rows", nil];
  
    chestexerciseList=[[NSMutableArray alloc] init];
    
    for (int i=0 ; i<exerciseList.count; i++) {
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setObject:[exerciseList objectAtIndex:i] forKey:@"exerciseName"];
        [dict setObject:@"0" forKey:@"showCross"];

        [chestexerciseList addObject:dict];
        
    }
    
    
    
    
    
    
    
    UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]
                                          initWithTarget:self action:@selector(handleLongPress:)];
    lpgr.minimumPressDuration = 2.0; //seconds
    lpgr.delegate = self;
    [customExerciseTableView addGestureRecognizer:lpgr];
//
//    chestexerciseList=[[NSMutableArray alloc] initWithObjects:@"btn_latradses_active",@"btn_frontsquat_active",@"btn_netmoverrow_active", nil];
//
    // Do any additional setup after loading the view.
}

-(void)handleLongPress:(UILongPressGestureRecognizer *)gestureRecognizer
{
    CGPoint p = [gestureRecognizer locationInView:customExerciseTableView];
    
    NSIndexPath *indexPath = [customExerciseTableView indexPathForRowAtPoint:p];
    if (indexPath == nil) {
        NSLog(@"long press on table view but not on a row");
    } else if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
        NSLog(@"long press on table view at row %ld", indexPath.row);
        
        if ([[[chestexerciseList objectAtIndex:indexPath.row] valueForKey:@"showCross"] isEqualToString:@"1"]) {
            [[chestexerciseList objectAtIndex:indexPath.row] setObject:@"2" forKey:@"showCross"];
            [customExerciseTableView reloadData];
        }
        
        
        
    } else {
        NSLog(@"gestureRecognizer.state = %ld", gestureRecognizer.state);
    }
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (tableView == chestBodyTableView) {
        return [chestList count];
    }
    else{
        return [chestexerciseList count];
        
        
    }
    
    //count number of row from counting array hear cataGorry is An Array
}



- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (tableView == chestBodyTableView) {
        static NSString *MyIdentifier = @"ChestCell";
        
        ChestCell=[tableView dequeueReusableCellWithIdentifier:MyIdentifier];
        ChestCell.chestListImg.tag=indexPath.row;
        ChestCell.chestListImg.image=[UIImage imageNamed:[chestList objectAtIndex:indexPath.row]];
        //    INTROCELL.lbl.text=[catagorry objectAtIndex:indexPath.row];
        return ChestCell;
    }
    else{
        static NSString *MyIdentifier = @"ChestCell";
        
        ChestCell=[tableView dequeueReusableCellWithIdentifier:MyIdentifier];
        ChestCell.chestListImg.tag=indexPath.row;
        ChestCell.cellLabel.text = [[NSString stringWithFormat:@"(%@) (5)",[[chestexerciseList objectAtIndex:indexPath.row] valueForKey:@"exerciseName"]] uppercaseString];
            ChestCell.swipeLabel.text = [[NSString stringWithFormat:@"(%@) (5)",[[chestexerciseList objectAtIndex:indexPath.row] valueForKey:@"exerciseName"]] uppercaseString];
       
        
        if ([[[chestexerciseList objectAtIndex:indexPath.row] valueForKey:@"showCross"] isEqualToString:@"0"]) {
            ChestCell.deleteButon.hidden = YES;
            ChestCell.cellLabel.hidden = NO;
            ChestCell.cellImage.hidden = NO;
            ChestCell.swipeLabel.hidden = YES;
            ChestCell.swipeImage.hidden = YES;

            
            
            
        }
        else if ([[[chestexerciseList objectAtIndex:indexPath.row] valueForKey:@"showCross"] isEqualToString:@"1"]) {
            ChestCell.deleteButon.hidden = YES;
            ChestCell.cellLabel.hidden = NO;
            ChestCell.cellImage.hidden = NO;
            ChestCell.swipeLabel.hidden = YES;
            ChestCell.swipeImage.hidden = YES;

        }
        else{
            ChestCell.deleteButon.hidden = NO;
            ChestCell.cellLabel.hidden = YES;
            ChestCell.cellImage.hidden = YES;
            ChestCell.swipeLabel.hidden = NO;
            ChestCell.swipeImage.hidden = NO;

            
        }
        ChestCell.deleteButon.tag = indexPath.row;
        
        [ChestCell.deleteButon addTarget:self action:@selector(deleteCell:) forControlEvents:UIControlEventTouchUpInside];
        
        //    INTROCELL.lbl.text=[catagorry objectAtIndex:indexPath.row];
        return ChestCell;
        
        
    }
}

-(void)deleteCell:(UIButton *)sender{
    NSLog(@"%ld",(long)sender.tag);
    
    [chestexerciseList removeObjectAtIndex:sender.tag];
    [customExerciseTableView reloadData];
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    if (tableView ==customExerciseTableView) {
        if ([[[chestexerciseList objectAtIndex:indexPath.row] valueForKey:@"showCross"] isEqualToString:@"2"]) {
            [[chestexerciseList objectAtIndex:indexPath.row] setObject:@"1" forKey:@"showCross"];
            [customExerciseTableView reloadData];
        }
    }


}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)backAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)startCustomAction:(id)sender {
    TempoScreenViewController *navToWorkbydate;
    
    navToWorkbydate=  [self.storyboard instantiateViewControllerWithIdentifier:@"TempoScreenViewController"];
    BOOL isPresent = NO;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:navToWorkbydate.class]) {
            [self.navigationController popToViewController:vc animated:YES];
            isPresent = YES;
        }
    }
    
    
    if (!isPresent) {
        //push controller
        [self.navigationController pushViewController:navToWorkbydate animated:YES];
        
    }
    


}

- (IBAction)addExercise:(id)sender {
    
    addExercisePopUop.hidden = NO;
    
    
}
- (IBAction)backPopUp:(id)sender {
    addExercisePopUop.hidden = YES;
    exerciseTextfield.text = @"";

}

- (IBAction)savePopUp:(id)sender {
    
    if ([exerciseTextfield.text isEqualToString:@""]) {
//        [self.view endEditing:YES];
//
//        addExercisePopUop.hidden = YES;
//
//        NSLog(@"empty textfiled");

        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please Enter some text" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
        
        
    }
  
    else
    {
    [self.view endEditing:YES];
    addExercisePopUop.hidden = YES;
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setObject:exerciseTextfield.text forKey:@"exerciseName"];
    [dict setObject:@"1" forKey:@"showCross"];
    
    [chestexerciseList addObject:dict];
    [customExerciseTableView reloadData];
    exerciseTextfield.text = @"";
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [self.view endEditing: YES];
    return true;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
