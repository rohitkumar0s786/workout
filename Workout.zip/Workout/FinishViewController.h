//
//  FinishViewController.h
//  Workout
//
//  Created by mac on 4/1/17.
//  Copyright © 2017 nitishMac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FinishViewController : UIViewController
{
    IBOutlet UIView *finishPopView;
    
    IBOutlet UITextField *customNameTextfield;
    
}
- (IBAction)countinueaAction:(id)sender;
- (IBAction)backPopUp:(id)sender;
- (IBAction)SaveDataYesButton:(id)sender;



@end
